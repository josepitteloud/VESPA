IF object_id('Data_Quality_Channel_Watching') IS not NULL drop procedure Data_Quality_Channel_Watching
commit

create procedure Data_Quality_Channel_Watching
    @target_date        date = NULL     -- Date of data analyzed or date process run
    ,@CP2_build_ID     bigint = NULL   -- Logger ID (so all builds end up in same queue)
as
begin
declare @viewing_data_date datetime

set @viewing_data_date = @target_date

EXECUTE logger_add_event @RunID , 3,'Data_Quality_Channel_Watching Start',0

select service_key, max(pk_channel_dim) pk_channel_dim
into #tmp_channel_key
from sk_prod.viq_channel
where date_from < @viewing_data_date
and date_to > @viewing_data_date
group by service_key

select a.service_key, a.channel_name 
into #tmp_final_channel
from sk_prod.viq_channel a,
 #tmp_channel_key b
where a.pk_channel_dim = b.pk_channel_dim

insert into data_quality_channel_check
(service_key, channel_name, viewing_data_date, live_recorded, num_of_instances, dq_run_id)
select a.*, @viewing_data_date viewing_data_date,b.live_recorded, count(b.pk_viewing_prog_instance_fact) num_of_instances, @CP2_build_ID
from 
#tmp_final_channel a
left outer join
data_quality_dp_data_audit b
on
(a.service_key = b.service_key)
group by a.service_key, a.channel_name, @viewing_data_date,b.live_recorded, @CP2_build_ID

commit


EXECUTE logger_add_event @RunID , 3,'Data_Quality_Channel_Watching Table Refresh End',0


----section to populate Excel tables with the actual records that have an issue--

EXECUTE logger_add_event @RunID , 3,'Data_Quality_Channel_Watching Issue Table Refresh Start',0

select convert(char,viewing_data_date, 112) event_date, service_key, live_recorded, max(pk_dq_chan_chk) pk_dq_chan_chk
into #tmp_pk_chan_chk
from data_quality_channel_check
group by convert(char,viewing_data_date, 112) , service_key, live_recorded

--gets those records with null viewing
select event_date, service_key
into #tmp_pk_chan_chk_null_view
from #tmp_pk_chan_chk
group by event_date, service_key
having count(distinct live_recorded) = 0

--gets those records with Live viewing only

select event_date, service_key
into #tmp_pk_chan_chk_one_type_view_live
from #tmp_pk_chan_chk
group by event_date, service_key
having count(distinct live_recorded) = 1
and sum(case when live_recorded = 'LIVE' then 1 else 0 end) = 1

--gets those records with Recorded viewing only

select event_date, service_key
into #tmp_pk_chan_chk_one_type_view_rec
from #tmp_pk_chan_chk
group by event_date, service_key
having count(distinct live_recorded) = 1
and sum(case when live_recorded = 'RECORDED' then 1 else 0 end) = 1

--gets those records where live records have fewer counts than recorded recorded 

select chan.service_key,convert(char,viewing.viewing_data_date, 112) event_date,viewing.channel_name, viewing.live_recorded playback_type, 
viewing.num_of_instances instances,
datepart(month,viewing.viewing_data_date) month,datepart(year,viewing.viewing_data_date) year
into #tmp_pk_chan_chk_viewing
from
data_quality_channel_service_key_list chan
inner join
data_quality_channel_check viewing
on
chan.service_key = viewing.service_key
inner join
#tmp_pk_chan_chk listing
on
viewing.pk_dq_chan_chk = listing.pk_dq_chan_chk
where chan.current_flag = 1

select service_key, event_date,case when playback_type = 'LIVE' then instances else 0 end LIVE_Instances
INTO #TMP_CHANNEL_LIVE_INSTANCES
FROM #tmp_pk_chan_chk_viewing
WHERE playback_type = 'LIVE' 

select service_key, event_date, case when playback_type = 'RECORDED' then instances else 0 end RECORDED_Instances
INTO #TMP_CHANNEL_REC_INSTANCES
FROM #tmp_pk_chan_chk_viewing
WHERE playback_type = 'RECORDED' 

SELECT a.*, b.RECORDED_Instances 
into #tmp_channel_live_less_rec
FROM #TMP_CHANNEL_LIVE_INSTANCES a,
#TMP_CHANNEL_REC_INSTANCES b
where a.service_key = b.service_key
and a.event_date = b.event_date
and (1.0 * a.live_instances/ (a.live_instances + b.recorded_instances)) * 100 < 10


select view_final.* into #tmp_pk_chan_chk_viewing_final
from #tmp_pk_chan_chk_viewing view_final
inner join
#tmp_channel_live_less_rec live_less_rec
on
view_final.service_key = live_less_rec.service_key 
and view_final.event_date = live_less_rec.event_date

insert into #tmp_pk_chan_chk_viewing_final
select view_final.* 
from #tmp_pk_chan_chk_viewing view_final 
inner join
#tmp_pk_chan_chk_null_view null_view
on
view_final.service_key = null_view.service_key 
and view_final.event_date = null_view.event_date

insert into #tmp_pk_chan_chk_viewing_final
select view_final.* 
from #tmp_pk_chan_chk_viewing view_final 
inner join
#tmp_pk_chan_chk_one_type_view_rec rec_view
on
view_final.service_key = rec_view.service_key 
and view_final.event_date = rec_view.event_date

delete from data_quality_channel_issues_list

insert into data_quality_channel_issues_list
select * into data_quality_channel_issues_list
from #tmp_pk_chan_chk_viewing_final

commit


EXECUTE logger_add_event @RunID , 3,'Data_Quality_Channel_Watching Issue Table Refresh End',0

EXECUTE logger_add_event @RunID , 3,'Data_Quality_Channel_Watching Process End',0

end

go
